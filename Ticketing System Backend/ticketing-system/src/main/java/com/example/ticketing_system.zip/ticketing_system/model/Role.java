package com.example.ticketing_system.model;

public enum Role {
    VENDOR,
    CUSTOMER
}
